using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace RecipeManager
{
    class RecipeManagerTests
    {
        static void Main(string[] args)
        {
            TestTotalCalorieCalculation();
            Console.WriteLine("All tests passed.");
        }

        static void TestTotalCalorieCalculation()
        {
            // Create a new recipe
            Recipe recipe = new Recipe("Test Recipe");

            // Add ingredients to the recipe
            recipe.AddIngredient("Ingredient1", "1", "cup", 100, "Dairy");
            recipe.AddIngredient("Ingredient2", "2", "tbsp", 50, "Spice");
            recipe.AddIngredient("Ingredient3", "3", "grams", 200, "Protein");

            // Expected total calories
            int expectedTotalCalories = 350;

            // Use reflection to get the private field totalCalories
            var totalCaloriesField = typeof(Recipe).GetField("totalCalories", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
            int actualTotalCalories = (int)totalCaloriesField.GetValue(recipe);

            // Assert the expected total calories match the actual total calories
            Debug.Assert(actualTotalCalories == expectedTotalCalories, $"Expected total calories: {expectedTotalCalories}, but got: {actualTotalCalories}");
        }
    }
}